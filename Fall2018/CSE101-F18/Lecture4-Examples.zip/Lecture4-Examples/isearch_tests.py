# This file contains some tests of the isearch function from the
# IterationLab module.

from PythonLabs.IterationLab import isearch
from PythonLabs.Tools import RandomList

notes = ['do', 're', 'me', 'fa', 'sol', 'la', 'ti']
print(isearch(notes, 'ti'))  # returns 6   #similar to Python index function
print(isearch(notes, 'ba'))  # returns None

rand_nums = RandomList(10)
print(rand_nums)

fish = RandomList(5, 'fish')
print(fish)

success_fish = fish.random('success')
print(success_fish)
print("The index of ", success_fish, " in a list ", fish, "is ", isearch(fish, success_fish))

fail_fish = fish.random('fail')
print("fail_fish = ", fail_fish)

print(isearch(fish, fail_fish))  # returns None


#1) using RandonList function, create a list of 15 random numbers.
rand_nums = RandomList(1000)
print(rand_nums)
#2) using function random, get a number which exists in a list obtained in the first step.
success_num = rand_nums.random('success')
print("success_num = ", success_num)
#3) using isearch function, find the index of number obtained in step 2.
index = isearch(rand_nums, success_num)
print("index of success_num is ", index)
#4) using function random, get a number which does not exist in a list obtained in the first step.
fail_num = rand_nums.random('fail')
print("fail_num = ", fail_num)
#5) using isearch function, find the index of number obtained in step 4.
index = isearch(rand_nums, fail_num)
print("index of fail_num is ", index)

total_comparisons = 0
for i in range(1000):
    success_num = rand_nums.random('success')
    index = isearch(rand_nums, success_num)
    print("number of comparisons to find success_num =  ", (index + 1))
    total_comparisons += index + 1
print('average comparisons are = ', total_comparisons/1000.0)




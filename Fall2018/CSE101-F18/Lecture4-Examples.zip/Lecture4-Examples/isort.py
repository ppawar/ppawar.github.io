def moveLeft(a,j):
    x = a.pop(j)
    while j > 0 and a[j-1] > x:
        j -= 1
    a.insert(j,x)

a = [1,3,4,6,2,7,5]
#moveLeft(a,6)
print(a)

def isort(a):
    for i in range(1, len(a)):
        moveLeft(a,i)
        print("i = ", i, " list = ",a)

isort(a)
print(a)
from PythonLabs.RecursionLab import print_msort_brackets, merge_groups, \
    RandomList, Counter

def msort(a):
    size = 1
    while size < len(a):
        print_msort_brackets(a, size)
        merge_groups(a, size)
        size *= 2
    print_msort_brackets(a, len(a))

Counter.reset('comparisons')
nums = RandomList(16)
print('nums:')
print(str(nums))
msort(nums)
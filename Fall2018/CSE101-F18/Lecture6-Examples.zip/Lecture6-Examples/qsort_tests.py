from RecursionLab import RandomList

def qsort(a):
    qs(a, 0, len(a)-1)  # sort the entire list

def qs(a, p, r):
    print('qs({}, {}, {})'.format(a, p, r))
    if p < r:          # base case: region has 0 elements
        q = partition(a, p, r)
        print('    a is now: ' + str(a))
        qs(a, p, q-1)  # recursively sort first and
        qs(a, q+1, r)  #    second sub-regions

def partition(a, p, r):
    x = a[p]
    i = p
    for j in range(p+1, r+1):
        if a[j] <= x:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[p], a[i] = a[i], a[p]
    return i

# Test the partition() function
nums = RandomList(8)
print('nums: ' + str(nums))
print('pivot element: ' + str(nums[0]))
partition(nums, 0, len(nums)-1)
print('nums after partitioning: ' + str(nums))

print()
nums = [55, 46, 89, 64, 93, 45, 15, 96]
qsort(nums)
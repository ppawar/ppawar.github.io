from PythonLabs.BitLab import Node, read_frequencies, init_queue, assign_codes


def build_tree(filename):
    pq = init_queue(read_frequencies(filename))
    while len(pq) > 1:
        n1 = pq.pop()  # remove 1st element
        n2 = pq.pop()  # remove 2nd element
        pq.insert(Node(n1, n2))
    return pq[0]


at = build_tree('../PythonLabs/data/huffman/hafreq.txt')
codes = assign_codes(at)
print(codes)


def encode(word, encodings):
    result = ''
    for letter in word:
        result += encodings[letter]
    return result


def decode(encoded, decodings):
    result = ''
    while len(encoded) > 0:
        for i in range(1, len(encoded) + 1):
            if encoded[:i] in decodings.keys():
                result += decodings[encoded[:i]]
                encoded = encoded[i:]
                break
    return result


huffman_codes = {
    "'": '0111', 'A': '10', 'E': '1101',
    'H': '0001', 'I': '1111', 'K': '001',
    'L': '0000', 'M': '11000', 'N': '1110',
    'O': '010', 'P': '110011', 'U': '0110',
    'W': '110010'}

reversed_codes = {huffman_codes[key]: key for key in huffman_codes.keys()}

print(encode('MAUI', huffman_codes))
print(decode('110001001101111', reversed_codes))

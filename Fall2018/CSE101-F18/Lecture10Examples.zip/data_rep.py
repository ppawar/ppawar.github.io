def dec2bin(decimal):
    binary = ''
    while decimal > 0:
        remainder = decimal % 2
        binary = str(remainder) + binary
        decimal //= 2
    return binary


# p    bit
# 0 XOR 0 = 0
# 0 XOR 1 = 1
# 1 XOR 0 = 1
# 1 XOR 1 = 0
def parity(bits):
    p = 0
    for bit in bits:
        # uncomment the next line to see how p changes over time
        # print('p: {}, bit: {}, p ^ bit: {}'.format(p, bit, p ^ int(bit)))
        p = p ^ int(bit)  # can also be written p ^= bit
    return p


print('Testing dec2bin():')
print('dec2bin(23):  ' + str(dec2bin(23)))   # 10111
print('dec2bin(100): ' + str(dec2bin(100)))  # 1100100
print('dec2bin(123): ' + str(dec2bin(123)))  # 1111011

print('\nTesting chr():')
print('chr(65):  ' + chr(65))
print('chr(33):  ' + chr(33))
print('chr(120): ' + chr(120))
print('chr(960): ' + chr(960))
print('chr(9829: ' + chr(9829))

print('\nExperiments with Unicode values:')
print('\\u2666: \u2665')  # heart
print('\\u05D0: \u05D0')  # Hebrew
print('\\u072E: \u072E')  # Arabic
print('\\u0986: \u0986')  # Bengali
print('\\u4E15: \u4E15')  # CJK Unified
print('\\u260E: \u260E')  # Telephone
print('\\u2602: \u2602')  # Umbrella

print('\nTesting ord():')
print("ord('A'): " + str(ord('A')))
print("ord('!'): " + str(ord('!')))
print("ord('x'): " + str(ord('x')))
print("ord('π'): " + str(ord('π')))

print('\nTesting parity():')
code = dec2bin(ord('A'))
print('A: ' + code)
print('Parity bit for A: ' + str(parity(code)))
code = dec2bin(ord('C'))
print('\nC: ' + code)
print('Parity bit for C: ' + str(parity(code)))

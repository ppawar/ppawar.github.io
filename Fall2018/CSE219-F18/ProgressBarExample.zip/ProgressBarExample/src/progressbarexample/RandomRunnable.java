/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressbarexample;

/**
 *
 * @author SUNY Korea CS
 */
public class RandomRunnable implements Runnable {
    private Thread proxyThread = null;
    private boolean die = false;
    
    public static void main(String[] args)
    {
        RandomRunnable rr = new RandomRunnable();
        rr.start();
    }
    
    public void kill() { die = true; }
    
    public void run() {
        while (!die)
        {
            int num = (int) (Math.random() * 10);
            System.out.println("\t\t\t\t" + num);
            try { Thread.sleep(10); }
            catch(InterruptedException ie) {}
        }
    }
    
    public void start() {
        if (proxyThread == null) {
            proxyThread = new Thread(this);
            proxyThread.start();
        }
    }
}

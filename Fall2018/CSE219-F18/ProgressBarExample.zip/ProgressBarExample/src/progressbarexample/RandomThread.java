/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressbarexample;

/**
 *
 * @author SUNY Korea CS
 */
public class RandomThread extends Thread {
    public void run()
    {
        while (true)
        {
            int num = (int) (Math.random() * 10);
            System.out.println("\t\t\t\t" + num);
            Thread.yield();
            try { Thread.sleep(100); }
            catch(InterruptedException ie) {}
        }
    }

}

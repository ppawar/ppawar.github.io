/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressbarexample;

import java.time.LocalDateTime;

/**
 *
 * @author SUNY Korea CS
 */
public class StartTester {
    public static void main(String[] args)
    {
        RandomThread thread = new RandomThread();
        thread.start();
        while (true)
        {
 	    LocalDateTime today = LocalDateTime.now();
            long hour = today.getHour();
            long minute = today.getMinute();
            long second = today.getSecond();
            System.out.println(hour + ":"
                    + minute + ":" + second);
            try { Thread.sleep(100); }
            catch(InterruptedException ie) {}        
        }
    }
}

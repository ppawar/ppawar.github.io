package progressbarexample;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
/**
 * @author THE McKilla Gorilla (i.e. Richard McKenna
 * © 2018
 */
public class ProgressBarExample extends Application {
    Button resetButton = new Button("Reset");
    Button startButton = new Button("Start");
    ProgressBar pBar = new ProgressBar();
    ProgressIndicator pIndicator = new ProgressIndicator();

    @Override
    public void start(Stage primaryStage) {
        VBox pane = new VBox();
        pane.setAlignment(Pos.CENTER);
        pane.getChildren().add(resetButton);
        pane.getChildren().add(startButton);
        pane.getChildren().add(pBar);
        pane.getChildren().add(pIndicator);
        resetButton.setOnAction(e -> {
            pBar.setProgress(0.0);
            pIndicator.setProgress(0.0);
        });
        startButton.setOnAction(e -> {
            Task<Void> task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    for (int i = 0; i <= 1000; i++) {
                        ProgressUpdater updater = new ProgressUpdater(i/100.0);
                        Platform.runLater(updater);
                        try { Thread.sleep(1000); } 
                        catch (InterruptedException ie) {
                            ie.printStackTrace();
                        }
                    }
                    return null;
                }
            };
            Thread thread = new Thread(task);
            thread.start();
        });

        Scene scene = new Scene(pane, 500, 300);
        primaryStage.setTitle("Progress!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    class ProgressUpdater implements Runnable {
        double progressValue;
        public ProgressUpdater(double initP) {
            progressValue = initP;
            System.out.println("progressValue is " + progressValue);
        }
        @Override
        public void run() {
            pBar.setProgress(progressValue);
            pIndicator.setProgress(progressValue);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
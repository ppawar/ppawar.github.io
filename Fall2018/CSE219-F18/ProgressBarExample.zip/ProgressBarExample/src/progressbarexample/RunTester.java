/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressbarexample;

import java.time.LocalDateTime;

/**
 *
 * @author SUNY Korea CS
 */
public class RunTester
{
    public static void main(String[] args)
    {
        RandomThread thread = new RandomThread();
        thread.run();
        while (true)
        {
            LocalDateTime today = LocalDateTime.now();
            long hour = today.getHour();
            long minute = today.getMinute();
            long second = today.getSecond();
            System.out.println(hour + ":"
                    + minute + ":" + second);
            try { Thread.sleep(10); }
            catch(InterruptedException ie) {}        }
    }
}

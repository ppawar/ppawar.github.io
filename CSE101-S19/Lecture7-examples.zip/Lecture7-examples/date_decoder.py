# The date_decoder() function converts a string containing a date
# (e.g., '8-MAR-85') into a tuple (year, month, day) (e.g., (1985, 3, 8)).

def date_decoder(date):
    months = {'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
              'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12}
    parts = date.lower().split('-')
    day = int(parts[0])
    month = months[parts[1]]
    year = 1900 + int(parts[2])
    if int(parts[2]) <= 69:
        year += 100
    return year, month, day

print(date_decoder('8-MAR-85'))
print(date_decoder('17-Apr-25'))

# The wc() function counts the number of lines, words and characters in
# a particular file.

def wc(filename):
    nlines = nwords = nchars = 0
    for line in open(filename):
        nlines += 1
        nwords += len(line.split())
        nchars += len(line)
    return nlines, nwords, nchars

lines, words, chars = wc('./good.txt')
print(lines, words, chars)

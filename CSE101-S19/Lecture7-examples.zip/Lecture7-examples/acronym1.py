# This function creates an acronym of the input phrase.

# version 1 of function
def acronym(phrase):
    result = ''
    words = phrase.split()
    for w in words:
        if len(w) > 3:
            result += w.upper()[0]
    return result

print(acronym('State University of New York at Stony Brook'))
print(acronym('Association for Computing Machinery'))
print(acronym('United States of America'))

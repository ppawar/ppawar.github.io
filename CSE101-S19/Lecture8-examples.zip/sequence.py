class Sequence:

    def __init__(self, seq):
        self._seq = seq

    def __repr__(self):
        return(self._seq)

    def mutate(self, pos, ch):
        self._seq = self._seq[:pos] + ch + self._seq[pos + 1:]

    def delete(self, pos, num):
        self._seq = self._seq[:pos] + self._seq[pos + num:]

seq1 = Sequence("ATCGTGCATGCA")
print(seq1)
seq1.mutate(0, 'G')
print(seq1)
seq1.delete(1, 3)
print(seq1)



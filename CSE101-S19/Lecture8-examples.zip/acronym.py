def acronym(phrase, includeshort=False):
    result = ''
    words = phrase.split()
    for w in words:
        if len(w) > 3:
            result += w.upper()[0]
        elif (includeshort):
            result += w
    return result

print(acronym("Republic of Korea", True))
print(acronym("Democratic Republic of Korea"))

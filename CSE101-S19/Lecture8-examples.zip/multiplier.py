def multiplier(n, m=True, sm=20):
    if m:
        return n * sm
    else:
        return n * n

print(multiplier(5))

print(multiplier(5, sm=7, m=False))

#print(multiplier(5, 8, 10))



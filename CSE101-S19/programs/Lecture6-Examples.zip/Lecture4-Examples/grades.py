# This program computes a student's grade according to a peculiar
# grading scheme.

def compute_grade(exam1_score, exam2_score, final_exam_score):
    normal_grade = 0.25 * exam1_score + 0.25 * exam2_score + \
                   0.5 * final_exam_score

    if exam1_score < 60 or exam2_score < 60:
        grade = 50
    elif exam1_score >= 90 and exam2_score >= 90 and \
        (exam1_score + exam2_score) / 2 > normal_grade:
        grade = (exam1_score + exam2_score) / 2
    else:
        grade = normal_grade

    return grade

exam1 = int(input("Enter exam #1 score: "))
exam2 = int(input("Enter exam #2 score: "))
final_exam = int(input("Enter final exam score: "))

print("Course grade: " + str(compute_grade(exam1, exam2, final_exam)))

# Define an "almost-lucky number" as a positive integer that is divisible
# by a lucky number. A lucky number is a positive integer whose decimal
# (base 10) representation contains only the lucky digits 4 and 7.
# The almost_lucky_divisor() function below returns the largest lucky number
# that divides evenly into num if num is an almost-lucky number. Otherwise,
# the function returns None if num is not an almost-lucky number.

def is_lucky_number(num):
    if num <= 0:
        return False      # negative numbers and zero are unlucky
    while num > 0:
        # is the rightmost digit either 4 or 7?
        if num % 10 == 4 or num % 10 == 7:
            num //= 10  # discard the rightmost digit because
        else:           # we found a 4 or a 7
            return False  # the rightmost digit was neither 4 nor 7
    return True  # every digit we looked at was a 4 or a 7, so return True

def almost_lucky_divisor(num):
    for divisor in range(num, 0, -1):
        if num % divisor == 0 and is_lucky_number(divisor):
            return divisor
    return None

print(almost_lucky_divisor(52))    # 4
print(almost_lucky_divisor(4474))  # 4474
print(almost_lucky_divisor(9))     # None
print(almost_lucky_divisor(611))   # 47

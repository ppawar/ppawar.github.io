# This program determines whether a year is a leap year.
# A year is a leap year if:
#    it is greater than 1582, and
#    it is divisible by 4, except centenary years not divisible by 400
#    (e.g., 1700, 1800, 1900, 2100, etc.)

year = int(input('Enter a year: '))

if year < 1582:
    print('You must enter a year >= 1582.')
else:
    if ((year % 4 == 0) and (year % 100 != 0)) or (year % 400 == 0):
        print('That is a leap year.')
    else:
        print('That is NOT a leap year.')

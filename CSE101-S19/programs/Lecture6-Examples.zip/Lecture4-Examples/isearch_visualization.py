from PythonLabs.IterationLab import view_list, isearch
from PythonLabs.Tools import RandomList

nums = RandomList(50)
print('nums: ' + str(nums))
target = nums.random('fail') # try it with 'fail' too
print('target: ' + str(target))
view_list(nums)
result = isearch(nums, target)
print('result: ' + str(result))
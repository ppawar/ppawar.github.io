def dec2bin(decimal):
    binary = ''
    while decimal > 0:
        remainder = decimal % 2
        binary = str(remainder) + binary
        decimal //= 2
    return binary


print('\nExperiments with Unicode values:')
print('\\u2666: \u2665')  # heart
print('\\u05D0: \u05D0')  # Hebrew
print('\\u072E: \u072E')  # Arabic
print('\\u0986: \u0986')  # Bengali
print('\\u4E15: \u4E15')  # CJK Unified
print('\\u260E: \u260E')  # Telephone
print('\\u2602: \u2602')  # Umbrella
print('\\uAC11: \uAC111')

print('\nTesting ord():')
print("ord('A'): " + str(ord('A')))
print("ord('!'): " + str(ord('!')))
print("ord('♥'): " + str(ord('♥')))
print("ord('π'): " + str(ord('π')))
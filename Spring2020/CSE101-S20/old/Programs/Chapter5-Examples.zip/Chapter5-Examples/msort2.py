# This is a version that does not use PythonLabs.
# This is simple because it only shows the minimum that we need to
# do merge sort without the clutter with PythonLabs stuff.
#
# This one also uses its own merge function rather than using one from
# the 'heapq' module

# u and v are sorted lists in increasing order. The elements in u and v
# can be compared using <, >, <=, and >=.
def merge(u, v):
    res = []
    i = 0
    j = 0
    while True:
        if (i < len(u)) and (j < len(v)):
            if u[i] < v[j]:
                res.append(u[i])
                i = i + 1
            else:
                res.append(v[j])
                j = j + 1
        elif (i < len(u)) and (j >= len(v)):
            res = res + u[i : len(u)]
            return res
        elif (i >= len(u)) and (j < len(v)):
            res = res + v[j : len(v)]
            return res
        else: # (i >= len(u)) and (j >= len(v))
            print('cannot be here')
            return None
        
def merge_groups(a, group_size):
   for i in range(0, len(a), 2 * group_size):
      j = i + group_size
      k = j + group_size
      a[i:k] = merge(a[i:j], a[j:k])

def msort(a):
    size = 1
    while size < len(a):
        merge_groups(a, size)
        size = size * 2

def main():
    # msort test
    nums = [5, 32, 1, 21, 6, 7, 56, 45, 3, 23, 2, 57]
    print('Before sort:', nums)
    msort(nums)
    print('After sort:', nums)

    # merge test:
    print('merge test: ' + str(merge([1, 2, 4, 5, 6, 7, 8, 9], [2, 3, 5, 8, 9])))

main()

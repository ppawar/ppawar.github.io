from PythonLabs.RecursionLab import *

def bsearch(a, x):
    lower = -1                      # set lower ptr to left end of list
    upper = len(a)                  # set upper ptr to right end of list
    while upper > lower + 1:        # while the two ptrs don't coincide:
        mid = (lower + upper) // 2  # get the index of the middle element of
        print_bsearch_brackets(a, lower, mid, upper)
        if a[mid] == x:             #    current region and return that index
            return mid              #    if the middle element is the target
        if x < a[mid]:              # the target is somewhere to the left of
            upper = mid             #    the middle, so update the search region
        else:                       # the target is somewhere to the right of
            lower = mid             #    the middle, so update the search region
    return None

nums = RandomList(10, sorted=True)
print('nums: ' + str(nums))

target = nums.random('success')
print('binary search for ' + str(target) + ': ')
print('result: ' + str(bsearch(nums, target)))

target = nums.random('fail')
print('binary search for ' + str(target) + ': ')
print('result: ' + str(bsearch(nums, target)))
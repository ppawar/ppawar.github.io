# This is a version that does not use PythonLabs.
# This is simple because it only shows the minimum that we need to
# do merge sort without the clutter with PythonLabs stuff.

import heapq

def merge_groups(a, group_size):
   for i in range(0, len(a), 2 * group_size):
      j = i + group_size
      k = j + group_size
      a[i:k] = list(heapq.merge(a[i:j], a[j:k]))

def msort(a):
    size = 1
    while size < len(a):
        merge_groups(a, size)
        size = size * 2

nums = [5, 32, 1, 21, 6, 7, 56, 45, 3, 23, 2, 57]
print('Before sort:', nums)
msort(nums)
print('After sort:', nums)

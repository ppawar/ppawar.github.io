from PythonLabs.RecursionLab import RandomList

def rsearch(a, x, lower, upper):
    if upper == lower + 1:
        return None
    mid = (lower + upper) // 2
    if a[mid] == x:
        return mid
    if x < a[mid]:
        return rsearch(a, x, lower, mid)
    else:
        return rsearch(a, x, mid, upper)


nums = RandomList(10, sorted=True)
print('nums: ' + str(nums))

target = nums.random('success')
print('binary search for ' + str(target) + ': ')
print('result: ' + str(rsearch(nums, target, -1, len(nums))))

target = nums.random('fail')
print('binary search for ' + str(target) + ': ')
print('result: ' + str(rsearch(nums, target, -1, len(nums))))
# The filesize() function counts the number of characters in a text file.

def filesize(filename):
    nchars = 0
    for line in open(filename):
        nchars += len(line)
    return nchars

print(filesize('./good.txt'))

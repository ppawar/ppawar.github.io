# This function creates an acronym of the input phrase.

# version 2 of function
def acronym(phrase, include_shorts=False):
    result = ''
    words = phrase.split()
    for w in words:
        if len(w) > 3:
            result += w.upper()[0]
        elif include_shorts:
            result += w.lower()[0]
    return result

print(acronym('State University of New York at Stony Brook'))
print(acronym('State University of New York at Stony Brook', True))
print(acronym('Association for Computing Machinery'))
print(acronym('Association for Computing Machinery', True))
print(acronym('United States of America'))
print(acronym('United States of America', True))
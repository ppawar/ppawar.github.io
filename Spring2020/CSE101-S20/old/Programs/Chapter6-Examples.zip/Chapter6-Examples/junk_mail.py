# These functions implement the spam filter algorithms described in the
# course textbook. The top-level function is pspam().

from PythonLabs.SpamLab import load_probabilities, combined_probability, WordQueue
import string


def tokenize(s):
    tokens = []
    for x in s.split():
        tokens.append(x.strip(string.punctuation).lower())
    return tokens


def wf(filename):
    count = {}
    for line in open(filename):
        for word in tokenize(line):
            count.setdefault(word, 0)
            count[word] += 1
    return count


def spamicity(w, pbad, pgood):
    if w in pbad and w in pgood:
        return pbad[w] / (pbad[w] + pgood[w])
    else:
        return None


def pspam(fn):
    queue = WordQueue(15)
    pbad = load_probabilities('email/bad.txt')
    pgood = load_probabilities('email/good.txt')
    with open(fn) as message:
        for line in message:
            for w in tokenize(line):
                p = spamicity(w, pbad, pgood)
                if p is not None:
                    queue.insert(w, p)
    return combined_probability(queue)


print(pspam('email/msg1.txt'))
print(pspam('email/msg2.txt'))
print(pspam('email/msg3.txt'))
print(pspam('email/msg4.txt'))

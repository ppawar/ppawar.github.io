from PythonLabs.IterationLab  import view_list, isort
from PythonLabs.Tools import RandomList
nums = RandomList(20)
print('nums before sorting: ' + str(nums))
view_list(nums)
isort(nums)
print('nums after sorting: ' + str(nums))

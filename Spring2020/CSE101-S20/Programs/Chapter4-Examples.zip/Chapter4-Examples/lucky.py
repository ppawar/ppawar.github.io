# Define a "lucky number" as a positive integer whose decimal (base 10)
# representation contains only the lucky digits 4 and 7. The function
# below returns True if its argument is a lucky number and False, otherwise.

def is_lucky_number(num):
    if num <= 0:
        return False      # negative numbers and zero are unlucky
    while num > 0:
        # is the rightmost digit either 4 or 7?
        if num % 10 == 4 or num % 10 == 7:
            num //= 10  # discard the rightmost digit because
        else:           # we found a 4 or a 7
            return False  # the rightmost digit was neither 4 nor 7
    return True  # every digit we looked at was a 4 or a 7, so return True

print(is_lucky_number(123))    # False
print(is_lucky_number(4474))   # True
print(is_lucky_number(0))      # False
print(is_lucky_number(73477))  # False

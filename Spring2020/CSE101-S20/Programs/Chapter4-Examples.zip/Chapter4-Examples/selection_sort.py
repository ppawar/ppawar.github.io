# An implementation of the selection sort algorithm.
from PythonLabs.Tools import RandomList

def selection_sort(a):
    for i in range(len(a)-1):         # process all but the rightmost element
        least_i = i                   # position of current smallest element
        for k in range(i+1, len(a)):  #    in the unsorted part of list
            if a[k] < a[least_i]:     # this for-loop searches for the smallest
                least_i = k           #    element in the unsorted part of the list
        a[least_i], a[i] = a[i], a[least_i]  # put the smallest element where it
                                             #     should go
nums = RandomList(10)
print('nums before sorting: ' + str(nums))
selection_sort(nums)
print('nums after sorting: ' + str(nums))
numCredits = int(input('Enter number of credits: '))

if numCredits < 12:
    cost = numCredits*600
    print('A student taking ' + str(numCredits) +
              ' credits is part-time and will pay $' + str(cost) + ' in tuition.')
else:
    print('A student taking ' + str(numCredits) +
              ' credits is full-time and will pay $5,000 in tuition.')

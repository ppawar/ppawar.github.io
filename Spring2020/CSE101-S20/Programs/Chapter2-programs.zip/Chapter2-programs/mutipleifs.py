def marginal_tax_rate(income):
    if income < 10000:
        return 0.0
    elif income < 20000:
        return 5.0
    else:
        return 7.0

print(marginal_tax_rate(25000))

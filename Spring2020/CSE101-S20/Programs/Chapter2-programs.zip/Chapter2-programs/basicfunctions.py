def f(x, y, z):
    product = x * y
    print("Product is: ", product)
    return product + z

'''
print(f(2, 3, 1))
print(f(4, 5, 6))
print(f(6, 7, 10))
print(f(8, 9, 11))
'''

def message():
    print(1)
    message1()
    print(2)

def message1():
    print('a')
    message2()
    print('b')

def message2():
    print('middle')

message()

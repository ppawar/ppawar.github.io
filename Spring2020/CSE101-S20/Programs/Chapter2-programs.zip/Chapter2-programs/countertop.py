def countertop(sideLength):
 """
 Compute the area of a square countertop with a missing wedge. The parameter x is
the length of one side of the square.
 """
 square = sideLength ** 2 # area of the full square
 triangle = ((sideLength / 2) ** 2) / 2 # area of the missing wedge
 return square - triangle

length = int(input("Enter the length of the side of rectangle:"))
area = countertop(length)
print("The area of countertop is ", area)
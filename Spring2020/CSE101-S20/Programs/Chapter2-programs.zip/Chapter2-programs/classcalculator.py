def classcalc(percentage):
    if 60 <= percentage <= 100:
        return "First class"
    elif 50 <= percentage < 60:
        return "Second class"
    elif 40 <= percentage < 50:
        return "Third class"
    elif 0 <= percentage < 40:
        return "Fail"
    else:
        return "Invalid percentage"

print(classcalc(75))
print(classcalc(57))
print(classcalc(45))
print(classcalc(25))
print(classcalc(-25))


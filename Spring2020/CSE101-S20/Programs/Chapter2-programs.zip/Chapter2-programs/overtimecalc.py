def calculate_pay(hours, wage):
    if hours <= 40 & hours > 0:
        return hours * wage
    else:
        return (hours - 40) * (1.5 * wage) + (40 * wage)

print(calculate_pay(-10, 10)) #300
print(calculate_pay(30, 10)) #300
print(calculate_pay(40, 10)) #400
print(calculate_pay(50, 10)) #550


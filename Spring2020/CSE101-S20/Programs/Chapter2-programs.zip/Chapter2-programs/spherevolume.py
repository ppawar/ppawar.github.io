import math

def sphereVolume(radius):
    volume = 4 / 3 * math.pi * radius ** 3
    return volume

print(sphereVolume(2.0))
print(sphereVolume(5.0))

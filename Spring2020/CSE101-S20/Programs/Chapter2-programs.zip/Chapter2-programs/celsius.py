def celsius(f):
    "Convert temperature f from Fahrenheit to Celsius."
    return (f - 32) * 5 / 9

print(celsius(30))
f = float(input("Enter temperature in Fahrenheit:"))
print(celsius(f))
help(celsius)

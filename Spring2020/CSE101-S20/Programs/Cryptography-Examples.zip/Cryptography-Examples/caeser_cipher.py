# Implementation of the Caesar cipher with shift amount.


def caesar_encrypt(plaintext, shift_amt):
    ciphertext = ''
    for ch in plaintext:
        if ch.isupper():
            replacement = (ord(ch) - ord('A') + shift_amt) % 26 + ord('A')
            ciphertext += chr(replacement)
        elif ch.islower():
            replacement = (ord(ch) - ord('a') + shift_amt) % 26 + ord('a')
            ciphertext += chr(replacement)
        else:
            ciphertext += ch
    return ciphertext


def caesar_decrypt(ciphertext, shift_amt):
    plaintext = ''
    for ch in ciphertext:
        if ch.isupper():
            replacement = (ord(ch) - ord('A') - shift_amt + 26) % 26 + ord('A')
            plaintext += chr(replacement)
        elif ch.islower():
            replacement = (ord(ch) - ord('a') - shift_amt + 26) % 26 + ord('a')
            plaintext += chr(replacement)
        else:
            plaintext += ch
    return plaintext

print(caesar_encrypt('The pen is mightier than the sword.', 3))
print(caesar_encrypt('Stony Brook', 3))
print(caesar_decrypt('Uvqpa Dtqqm', 2))

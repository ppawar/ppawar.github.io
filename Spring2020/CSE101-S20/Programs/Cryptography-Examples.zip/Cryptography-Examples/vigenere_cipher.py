# Implementation of the Vigenere cipher.
# Works with uppercase letters only.


def vigenere_encrypt(plaintext, keyword):
    # duplicate the keyword as many times as needed
    keyword = keyword * (len(plaintext) // len(keyword) + 1)

    # convert plaintext letters to numbers
    plaintext_nums = [ord(ch) - ord('A') for ch in plaintext]

    # convert keyword letters to numbers
    keyword_nums = [ord(ch) - ord('A') for ch in keyword]

    # generate ciphertext
    ciphertext = ''
    for i in range(len(plaintext)):
        # add the two numerical codes and map sum (mod 26) back to a letter
        ciphertext += chr((plaintext_nums[i] + keyword_nums[i])
                          % 26 + ord('A'))
    return ciphertext


def vigenere_decrypt(ciphertext, keyword):
    # duplicate the keyword as many times as needed
    keyword = keyword * (len(ciphertext) // len(keyword) + 1)
    # convert ciphertext letters to numbers
    ciphertext_nums = [ord(ch) - ord('A') for ch in ciphertext]
    # convert keyword letters to numbers
    keyword_nums = [ord(ch) - ord('A') for ch in keyword]

    # generate plaintext
    plaintext = ''
    for i in range(len(ciphertext)):
        # subtract keyword num from ciphertext num, add 26 and
        # and map difference (mod 26) back to a letter
        plaintext += chr((ciphertext_nums[i] - keyword_nums[i] + 26)
                         % 26 + ord('A'))
    return plaintext


print(vigenere_encrypt('COMPUTER', 'PYTHON'))  # RMFWIGTP
print(vigenere_decrypt('OIXGCWYR', 'JOKE'))    # FUNCTION

# Implementation of a multiplicative cipher, which is an affine
# cipher with a shift amount of 0.

import string


def multiplicative_encrypt(plaintext, k):
    ciphertext = ''
    for ch in plaintext:
        if ch.isupper():
            replacement = ((ord(ch) - ord('A')) * k) % 26 + ord('A')
            ciphertext += chr(replacement)
        elif ch.islower():
            replacement = ((ord(ch) - ord('a')) * k) % 26 + ord('a')
            ciphertext += chr(replacement)
        else:
            ciphertext += ch
    return ciphertext

reverse_mapping = {}
decrypt_key = -1
def multiplicative_decrypt(ciphertext, k):
    global reverse_mapping, decrypt_key
    # generate new mappings only if key has changed
    if k != decrypt_key:
        decrypt_key = k
        encrypted_letters = [multiplicative_encrypt(letter, k)
                             for letter in string.ascii_letters]
        reverse_mapping = {encrypted_letter: letter
                   for letter, encrypted_letter in
                   zip(string.ascii_letters, encrypted_letters)}

    plaintext = ''
    for ch in ciphertext:
        if ch in reverse_mapping:
            plaintext += reverse_mapping[ch]
        else:
            plaintext += ch

    return plaintext


print(multiplicative_encrypt('Stony Brook', 7))
print(multiplicative_decrypt('Wdunm Hpuus', 7))
print(multiplicative_encrypt('Stony Brook', 3))
print(multiplicative_decrypt('Cfqnu Dzqqe', 3))
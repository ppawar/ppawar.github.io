# Implementation of a railfence cipher (zigzag pattern).


def next_row(row, step, num_rows):
    if row == 0:
        step = 1
    elif row == num_rows - 1:
        step = -1
    row += step
    return row, step


def railfence_encrypt(plaintext, num_rows):
    row = 0
    step = 1
    rows = [''] * num_rows  # create num_rows empty strings in a list
    for ch in plaintext:
        rows[row] += ch
        row, step = next_row(row, step, num_rows)
    return ''.join(rows)


def railfence_decrypt(ciphertext, num_rows):
    grid = []
    for i in range(num_rows):
        grid += [[''] * len(ciphertext)]

    # set up the grid, placing a None value where each letter will go
    row = 0
    step = 1
    for col in range(len(ciphertext)):
        grid[row][col] = None
        row, step = next_row(row, step, num_rows)

    # place characters from the encrypted message in the grid
    next_char_index = 0
    for row in range(num_rows):
        for col in range(len(ciphertext)):
            if grid[row][col] is None:
                grid[row][col] = ciphertext[next_char_index]
                next_char_index += 1

    # read the characters from the grid in zigzag order
    plaintext = ''
    row = 0
    step = 1
    for col in range(len(ciphertext)):
        plaintext += grid[row][col]
        row, step = next_row(row, step, num_rows)

    return plaintext


print(railfence_encrypt('STONYBROOKUNIV', 3))
print(railfence_decrypt('SYOITNBOKNVORU', 3))

print(railfence_encrypt('STONYBROOKUNIV', 4))
print(railfence_decrypt('SRITBONVOYOUNK', 4))

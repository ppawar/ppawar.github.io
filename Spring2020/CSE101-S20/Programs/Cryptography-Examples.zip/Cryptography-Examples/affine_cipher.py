# Implementation of an affine cipher.


def affine_encrypt(plaintext, a, b):
    ciphertext = ''
    for ch in plaintext:
        if ch.isupper():
            replacement = ((ord(ch) - ord('A')) * a + b) % 26 + ord('A')
            ciphertext += chr(replacement)
        elif ch.islower():
            replacement = ((ord(ch) - ord('a')) * a + b) % 26 + ord('a')
            ciphertext += chr(replacement)
        else:
            ciphertext += ch
    return ciphertext


print(affine_encrypt('Stony Brook', 5, 8))
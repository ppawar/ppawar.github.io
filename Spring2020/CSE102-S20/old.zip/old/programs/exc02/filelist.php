<?php $filelist= array(
"FirstPage.html",
"GreenEarth.html",
"InlineQuote.html",
"Quote.html",
"Hrule.html",
"Pre.html",
"FontSize.html",
"FontFamily.html",
"List.html",
"Defs.html",
"MarkerStyle.html",
"Navbar.html",
"ImgLink.html",
"Float.html",
"FloatClear.html",
"ImgAlign.html",
"FigCap.html",
"Planets.html",
"Layout.html"
);

// print_r ($filelist);
?>

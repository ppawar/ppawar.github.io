var me=document.createElement('audio');
me.src="angels/angela_with_purple_bamboo.ogg";
me.autoplay=true;
me.controls=true;
document.getElementById('body').appendChild(me);

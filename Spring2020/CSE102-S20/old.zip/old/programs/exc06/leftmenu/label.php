<span class="menulabel"  
  onclick="menuActivate(event, this,
  '<?php echo $mid?>')" 
   onmouseover="menuShow(this, '<?php echo $mid?>')">
<?php echo $mtext?></span>
<?php include("$mid.inc"); ?>

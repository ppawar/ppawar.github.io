# The transform() function produces a response to a sentence passed in
# as an argument to the function.

from PythonLabs.Tools import tokenize
from PythonLabs.ElizaLab import PriorityQueue, Eliza

def transform(sentence):
    queue = PriorityQueue()
    sentence = Eliza.preprocess(sentence, Eliza.pre)

    for word in tokenize(sentence):
        rule = Eliza.rule_for(word)
        if rule is not None:
            queue.insert(rule)

    while len(queue) > 0:
        rule = queue.pop()
        response = rule.apply(sentence, post=Eliza.post)
        if response is not None:
            return response

# Main program
Eliza.load('../PythonLabs/data/eliza/doctor.txt')
print(transform('Are you a computer?'))
print(transform('Are you a computer?'))
print(transform('Are you a computer?'))
print(transform('Are you a computer?'))
print(transform('Are you a computer?'))
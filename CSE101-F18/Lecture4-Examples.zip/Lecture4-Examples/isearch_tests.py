# This file contains some tests of the isearch function from the
# IterationLab module.

from PythonLabs.IterationLab import isearch
from PythonLabs.Tools import RandomList

notes = ['do', 're', 'me', 'fa', 'sol', 'la', 'ti']
print(isearch(notes, 'ti'))  # returns 6
print(isearch(notes, 'ba'))  # returns None

rand_nums = RandomList(10)
print(rand_nums)

fish = RandomList(5, 'fish')
print(fish)

success_fish = fish.random('success')
print(isearch(fish, success_fish))

fail_fish = fish.random('fail')
print(isearch(fish, fail_fish))  # returns None

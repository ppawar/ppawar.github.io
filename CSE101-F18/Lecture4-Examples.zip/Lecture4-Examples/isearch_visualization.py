from PythonLabs.IterationLab import view_list, isearch
from PythonLabs.Tools import RandomList

nums = RandomList(20)
print('nums: ' + str(nums))
target = nums.random('success') # try it with 'fail' too
print('target: ' + str(target))
view_list(nums)
result = isearch(nums, target)
print('result: ' + str(result))
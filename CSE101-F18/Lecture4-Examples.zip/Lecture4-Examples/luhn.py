# This program implements the Luhn algorithm for checking if an
# account number is valid.
# See en.wikipedia.org/wiki/Luhn_algorithm for more details

def luhn(number):
    total = 0                             # the running total
    position = 1                          # keeps track of odd/even position

    while number > 0:
        digit = number % 10               # pull off the rightmost digit
        if position % 2 == 1:             # if it's an odd-positioned digit
            total += digit                #    then add it to the total
        else:                             # else it's even-positioned digit
            digit *= 2                    #    so double it
            if digit >= 10:               # if the doubled value is >= 10
                total += 1 + (digit % 10) #    then add individual digits
            else:                         # else the doubled value is < 10
                total += digit            #    so add it to the total as is

        number //= 10                     # discard the processed digit
        position += 1                     # update odd/even position

    return total % 10 == 0

acct_num = int(input('Enter an account number: '))
if luhn(acct_num):
    print('That is a valid account number.')
else:
    print('That is not a valid account number.')

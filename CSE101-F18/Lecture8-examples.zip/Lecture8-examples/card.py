class Card:

    """These are class variables"""
    # clubs, diamonds, hearts, spades
    suit_sym = {0: '\u2663', 1: '\u2666', 2: '\u2665', 3: '\u2660'}
    rank_sym = {0: '2', 1: '3', 2: '4', 3: '5', 4: '6', 5: '7', 6: '8',
                7: '9', 8: '10', 9: 'J', 10: 'Q', 11: 'K', 12: 'A'}

    """These are instance variables:
    _id (suit and rank combined into a single integer)
    """
        
    def __init__(self, n):
        if n in range(52):
            self._id = n
        else:
            raise Exception('Card number must be in the range 0-51.')

    def suit(self):
        return self._id // 13

    def rank(self):
        return self._id % 13

    def __repr__(self):
        return Card.rank_sym[self.rank()] + Card.suit_sym[self.suit()]

    def __lt__(self, other):
        return self._id < other._id

    def __eq__(self, other):
        return self._id == other._id


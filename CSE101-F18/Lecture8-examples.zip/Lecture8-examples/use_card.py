# Testing of Card class

import random
import card  # with this, you have to say card.xxx
             # see use_card2.py where you don't have to say card.xxx
             # because import is done differently there.

def new_deck():
    return [card.Card(i) for i in range(52)]

def shuffle(deck):
    for i in range(len(deck)):
        r = random.randint(0, len(deck)-1) # in the range of 0 and len(deck)-1 inclusive
        deck[i], deck[r] = deck[r], deck[i]

def make_card(n):
    try:
        return Card(n)
    except Exception as e:
        print('Invalid card: ' + str(e))
        return None

def main():
    u = [1, 2, 3, 4, 5, 6, 7]
    for i in range(0, len(u)):
        print(i)

    c = card.Card(46)
    print(c.suit())
    print(c.rank())
    print(card.Card(51))

    deck = new_deck()
    print(deck[:5])
    print(deck[47:])

    c1 = card.Card(3)
    c2 = card.Card(4)
    print(c1 < c2)
    print(c1.__lt__(c2))

    print(c1 == c2)
    print(c1.__eq__(c2))

    shuffle(deck)
    print(deck)

    cards_sorted = sorted(deck)
    print(cards_sorted)

    for i in range(10):
        print(random.randint(0, 3))

    print(card.Card.suit_sym)
    print(card.Card.rank_sym)

    make_card(234)


main()

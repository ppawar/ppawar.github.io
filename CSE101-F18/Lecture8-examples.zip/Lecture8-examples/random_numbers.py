# This program shows some basic examples of working with random integers.

import time
a = 81
c = 337
m = 1000
x = int(time.time()) % m

def rand():
    global x
    x = (a * x + c) % m
    return x

print('Random numbers in the range 0 through 999:')
for i in range(3):
    print(rand())

print('Random numbers in the range -5 through 10:')
for i in range(3):
    num = rand() % 16 - 5
    print(num)


function load() {
	var mydata = JSON.parse(data);
	alert(mydata);
	document.writeln(data);
}
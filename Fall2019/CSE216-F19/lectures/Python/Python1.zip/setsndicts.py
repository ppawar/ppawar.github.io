s = {"apple", "banana", "mango"}
print(type(s))
a = dict(one=1, two=2, three=3)
b = {'one': 1, 'two': 2, 'three': 3}
c = dict(zip(['one', 'two', 'three'], [1, 2, 3]))
d = dict([('two', 2), ('one', 1), ('three', 3)])
e = dict({'three': 3, 'one': 1, 'two': 2})
print(a == b == c == d == e)

a = dict(one=1, two=2, three=3)
print(a.keys())
print(list(a.keys()))
print(list(a.values()))
a['four'] = 4 # set key to value
a['four'] # return the value with this key
a['five'] # throw KeyError if key is not in dictionary
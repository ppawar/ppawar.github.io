from math import pi
radius = int(input("Enter the radius: "))
if radius >= 0:
    area = radius * radius * pi
    print("The area of a circle with radius ", radius, "is ", area)
else:
    print("I think that was an invalid in put")

score = int(input("Enter the score: "))
if score >= 90.0:
    grade = 'A'
elif score >= 80.0:
    grade = 'B'
elif score >= 70.0:
    grade = 'C'
elif score >= 60.0:
    grade = 'D'
else:
    grade = 'F'

words = ['cat', 'window', 'defenestrate']
for w in words:
    print(w, len(w))
for i in range(10):
    print(i**2)
a = ['Mary', 'had', 'a', 'little', 'lamb']
for i in range(len(a)):
    print(i, a[i])

for n in range(2, 10):
    for x in range(2, n):
        if n % x == 0:
            print(n, 'equals', x, '*', n//x)
            break
        else:
            print(n, 'is a prime number')

for num in range(2, 10):
    if num % 2 == 0:
        print("Found an even number", num)
        continue
    print("Found a number", num)
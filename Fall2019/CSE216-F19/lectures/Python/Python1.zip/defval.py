def def_test(arg = 0):
     print(arg)

def_test()
def_test(5)

def def_val_test(num, a_list = list()):
    a_list.append(num)
    return a_list

print(def_val_test(1))
print(def_val_test(2))
print(def_val_test(3))
print(def_val_test(4))
print(def_val_test(5))

def def_val_test1(num, a_list = list()):
    if a_list is None:
        a_list = list()
    a_list.append(num)
    return a_list

print(def_val_test1(1))
print(def_val_test1(2))
print(def_val_test1(3))
print(def_val_test1(4))
print(def_val_test1(5))
bob = ('Bob', 30, 'male')
print ('Representation:', bob)

jane = ('Jane', 29, 'female')
print ('\nField by index:', jane[0])

print ('\nFields by index:')
for p in [bob, jane]:
    print ('%s is a %d year old %s' % p)

import collections

Person = collections.namedtuple('Person', 'name age gender')

print ('Type of Person:', type(Person))

bob = Person(name='Bob', age=30, gender='male')
print ('\nRepresentation:', bob)

jane = Person(name='Jane', age=29, gender='female')
print ('\nField by name:', jane.name)

print ('\nFields by index:')
for p in [bob, jane]:
    print ('%s is a %d year old %s' % p)

from collections import namedtuple

Phone = namedtuple('Phone', ['owner', 'number'])
p = Phone('John', '1231231231')
print(p[0])
print(p.owner)
print(p.number)
print ("Type of P: ", type(p))

q = Phone('Jack', 1231231231)
print(q.number)
owner, number = q
print(owner)
print(number)

print(tuple("apple"))
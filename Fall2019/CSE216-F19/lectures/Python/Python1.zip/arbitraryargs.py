def cheeseshop(kind, *arguments, **keywords):
    print("-- Do you have any", kind, "?")
    print("-- I'm sorry, we're all out of", kind)
    for arg in arguments:
        print(arg)
        print("-" * 40)
    for kw in keywords:
        print(kw, ":", keywords[kw])

cheeseshop("Limburger", "It's runny mam!", "It's really really runny mam!!",
           shopkeeper="Michel Wang", client="Hyojung Kwon", sketch="Cheese shop sketch")
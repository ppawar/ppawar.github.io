def write_items(fname, seperator, *args):
    f = open(fname, "w+")
    f.write(seperator.join(args))
    f.close()

write_items("txtfile.txt", "\'", '1','2','3','4','5','6','7','8','9','10')

def fibseries(n):
    "Print a Fibonacci series up to n."
    a, b = 0, 1
    while a < n:
        print(a, end = ' ')
        a, b = b, a + b
    print()


def fib(n):
    "Print the nth Fibonacci number."
    if n < 0:
        print("Fibonacci series begins with n = 0")
    elif n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)
def confirmation(query, max_attempts=3, reminder='Please try again with a valid input.'):
    while True:
        response = input(query)
    if response in ('y', 'Y', 'yes', 'Yes', 'YES'):
        return True
    if response in ('n', 'N', 'no', 'No', 'NO'):
        return False
    max_attempts = max_attempts - 1
    if max_attempts < 0:
        raise ValueError('Too many invalid responses.')
    print(reminder)

confirmation("Are you sure?")
confirmation("Are you sure?", 1, "Please enter [Y]es/[N]o.")
#nonlocal variables
def outer():
    x = "local"
    y = "outery"
    def inner():
        nonlocal x
        x = "nonlocal"
        y = "innery"
        print("inner x:", x)
        print("inner y:", y)
    inner()
    print("outer x:", x)
    print("outer y:", y)
outer()

#local variable
def foo():
    y = "local"
    print(y)
foo()

#Global variable
x = "global"
def foo():
    print("x inside :", x)

foo()
print("x outside:", x)

def foo1():
    #global x
    x = x * 2
    print(x)
foo1()
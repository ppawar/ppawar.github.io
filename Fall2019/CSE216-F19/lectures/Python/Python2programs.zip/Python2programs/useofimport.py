import fibonacci
print(fibonacci.fib2(10))
del fibonacci

from fibonacci import fib, fib2
print(fib2(10))

import fibonacci as fibo
print(fibo.fib2(10))

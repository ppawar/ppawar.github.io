/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recitation7;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.*; 

/**
 *
 * @author SUNY Korea CS
 */
public class DColonDemo {
    
    // static function to be called 
    static void staticFunction(String s) 
    { 
        System.out.println(s); 
    } 
  
    // instance function to be called 
    void instanceFunction(String s) 
    { 
        System.out.println(s); 
    } 
    
    public static void main(String[] args) 
    { 
  
        // Get the stream 
        Stream<String> stream 
            = Stream.of("Geeks", "For", 
                        "Geeks", "A", 
                        "Computer", 
                        "Portal"); 
  
        // Print the stream 
        // using double colon operator 
        stream.forEach(System.out::println);
        
        List<String> list = new ArrayList<String>(); 
        list.add("Geeks"); 
        list.add("For"); 
        list.add("GEEKS"); 
        
        // call the static method 
        // using double colon operator 
        list.forEach(DColonDemo::staticFunction);
        
        // call the instance method 
        // using double colon operator 
        list.forEach((new DColonDemo())::instanceFunction); 
    } 
}

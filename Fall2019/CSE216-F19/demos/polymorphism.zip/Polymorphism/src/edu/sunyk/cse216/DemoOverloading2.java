package edu.sunyk.cse216;

public class DemoOverloading2
{
    public void disp(char c)
    {
         System.out.println(c);
    }
    public void disp(char c, int num)  
    {
         System.out.println(c + " "+num);
    }
}
class Sample
{
   public static void main(String args[])
   {
       DemoOverloading2 obj = new DemoOverloading2();
       obj.disp('a');
       obj.disp('a',10);
   }
}
<script>
  function $(id)
  {
    return document.getElementById(id)
  }
</script>
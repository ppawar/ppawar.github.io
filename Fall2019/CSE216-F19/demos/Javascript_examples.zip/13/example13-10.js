<script>
  function test()
  {
	    a = 123               // Global scope
	var b = 456               // Local scope
	if (a == 123) var c = 789 // Local scope
  }
</script>

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

public class ThreadPriority2 {

  public static void priorityTest() {
    Thread t1 = new Thread(new MyRunnableThread(), "Priority_10");
    Thread t2 = new Thread(new MyRunnableThread(), "Priority_8");
    Thread t3 = new Thread(new MyRunnableThread(), "Priority_6");
    Thread t4 = new Thread(new MyRunnableThread(), "Priority_4");
    Thread t5 = new Thread(new MyRunnableThread(), "Priority_2");
    
    t1.setPriority(10);
    t2.setPriority(8);
    t3.setPriority(6);
    t4.setPriority(4);
    t5.setPriority(2);

    t1.start();
    t2.start();
    t3.start();   
    t4.start();   
    t5.start();   
  }
  
  public static void main(String[] args) {
    priorityTest();
  }
}
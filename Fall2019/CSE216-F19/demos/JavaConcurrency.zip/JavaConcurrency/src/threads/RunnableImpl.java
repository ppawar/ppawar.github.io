package threads;


public class RunnableImpl implements Runnable {
    public void run() {
        System.out.println("A runnable implementation.");
    }
    public static void main(String... args) {
        (new Thread(new RunnableImpl())).start();
    }
}

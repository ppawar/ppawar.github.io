/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

public class Wool extends Thread {
@Override
public void run() {
System.out.printf("Running thread %d.%n", Thread.currentThread().getId());
try {
Thread.sleep(1000);
} catch (InterruptedException e) {
e.printStackTrace();
}
}

/** Put break points and use the debugger to see how many threads are running. */
public static void main(String... args) {
Wool t = new Wool();
System.out.printf("Running thread %d.%n", Thread.currentThread().getId());
t.run();
t.start();
}
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class JavaFXThreadInterrupt extends Application {
private static boolean _first_click = true;

    public static void main(String[] args) {
        Application.launch(args);
    }
@Override
public void start(Stage primaryStage) {
BorderPane borderPane = new BorderPane();
Button resetButton = new Button("Start Counter");

Thread countingThread = new Thread(new Runnable() {
@Override public void run() {
for (int i = 0; ; i++) {
try {
System.out.printf("%d ", i);
Thread.sleep(1000);
} catch (InterruptedException e) {
i = -1;
System.out.println();
}
}
}
});


resetButton.setOnMouseClicked(e -> {
resetButton.setText("Reset Counter");
if (_first_click) {
countingThread.start();
_first_click = false;
} else
countingThread.interrupt();
});

borderPane.setCenter(resetButton);
Scene scene = new Scene(borderPane, 400, 200);
primaryStage.setScene(scene);
primaryStage.setTitle("Counting Interruption Example");
primaryStage.show();
}
}
package threads;

public class SleepMessages {
public static void main(String[] args) throws InterruptedException {
String[] sentences = {"Mares eat oats",
"Does eat oats",
"Little lambs eat ivy",
"Kids will eat ivy too"};
for (String s : sentences) {
Thread.sleep(4000); // suspend execution for 4 seconds
System.out.println(s);
}
}
}

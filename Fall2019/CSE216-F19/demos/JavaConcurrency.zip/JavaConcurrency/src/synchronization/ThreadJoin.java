/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package synchronization;

import java.util.Random;

/**
 *
 * @author SUNY Korea CS
 */
public class ThreadJoin {
    public static void main(String... args) throws InterruptedException {
Thread t1 = new Thread(() -> {
try {
Thread.sleep(new Random().nextInt(2000));
} catch (InterruptedException ignore) {
/* do nothing */
}
System.out.println("Running t1.");
});
Thread t2 = new Thread(() -> {
try {
Thread.sleep(new Random().nextInt(4000));
} catch (InterruptedException ignore) {
/* do nothing */
}
System.out.println("Running t2.");
});
t1.start();
t2.start();
t1.join();
t2.join();
System.out.println("Running the main thread.");
}
}

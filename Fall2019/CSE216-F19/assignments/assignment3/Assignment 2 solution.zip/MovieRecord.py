from constants import getGenres, addLanguage, getProductionCountries, getProductionCompanies

class MovieRecord:
    def __init__(self, adult, genres, id, imdb_id, original_language, original_title,
                 popularity, production_companies, production_countries, release_date,
                 revenue, runtime, spoken_languages, status, title):
        self.adult = adult
        self.genres = genres
        self.id = id
        self.imdb_id = imdb_id
        self.original_language = original_language
        addLanguage(original_language)
        self.original_title = original_title
        self.popularity = float(popularity)
        self.production_companies = getProductionCompanies(production_companies)
        self.release_date = release_date
        self.revenue = int(revenue)
        if runtime == '':
            runtime = '-1'  #Not available
        self.runtime = int(runtime)
        self.spoken_languages = spoken_languages
        self.status = status
        self.title = title
        self.genreList = getGenres(genres)
        self.production_countries = getProductionCountries(production_countries)

    def __str__(self):
        return ("id: " + self.id + " imdb_id: " + self.imdb_id + " Release date: " + self.release_date
                + " Title: " + self.title)

    def __repr__(self):
        return ("id: " + self.id + " imdb_id: " + self.imdb_id + " Release date: " + self.release_date
                + " Title: " + self.title + " Genres: " + str(self.genreSet))


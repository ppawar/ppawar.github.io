from MovieRecord import MovieRecord
from datetime import datetime
import csv
#----------------------------------------------------------------------

movieItems = []

def csv_dict_reader(file_obj):
    """
    Read a CSV file using csv.DictReader
    The line is basically a dictionary object.
    """
    reader = csv.DictReader(file_obj, delimiter=',')
    for line in reader:
        if line["id"] != '':
            mRecord = MovieRecord(line["adult"], line["genres"], line["id"], line["imdb_id"], line["original_language"], line["original_title"],
                line["popularity"], line["production_companies"], line["production_countries"], line["release_date"],
                line["revenue"], line["runtime"], line["spoken_languages"], line["status"], line["title"])
            mDate = datetime.strptime(line["release_date"], "%m/%d/%Y").date()
            movieItem = {}
            movieItem['date'] = mDate
            movieItem['popularity'] = mRecord.popularity
            movieItem['revenue'] = mRecord.revenue
            movieItem['runtime'] = mRecord.runtime
            movieItem['title'] = mRecord.title
            movieItem['record'] = mRecord
            movieItems.append(movieItem)
    print("Total movie items = ", len(movieItems))
    movieItems.sort(key=lambda item:item['date'])
    return movieItems

if __name__ == "__main__":
    with open("movies_metadata_edited.csv", encoding="utf8") as f_obj:
        csv_dict_reader(f_obj)
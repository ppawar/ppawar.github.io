import ast

genreSet = set()
languageSet = set()
countrySet = set()

questionList = ["List most popular top 20 movies in a particular period.",
    "List most popular top 20 movies released in a particular language.",
    "List most popular top 20 movies released in a particular genre type.",
    "List most popular top 20 movies produced in a particular country.",
    "List top 20 movies which earned highest revenue in a particular period.",
    "List top 20 movies according to their runtime in a particular period.",
    "List the production companies of top 20 most popular movies in a particular period.",
    ]

def getQuestionDictList():
    qDictList = []
    for i in range(len(questionList)):
        qDict = {}
        qDict['num'] = i + 1
        qDict['question'] = questionList[i]
        qDictList.append(qDict)
    return qDictList

def getGenresSet():
    return sorted(genreSet)

def getLanguageSet():
    return sorted(languageSet)

def getCountrySet():
    return sorted(countrySet)

def addLanguage(language):
    languageSet.add(language)

def getGenres(genres):
    if (genres == "[]"):
        return []
    else:
        genresItems = ast.literal_eval(genres)
        genreList = []
        for item in genresItems:
            genreList.append(item['name'])
            genreSet.add(item['name'])
        return genreList

def getProductionCountries(production_countries):
    if (production_countries == "[]"):
        return []
    else:
        countryItems = ast.literal_eval(production_countries)
        countryList = []
        for item in countryItems:
            countryList.append(item['iso_3166_1'])
            countrySet.add(item['iso_3166_1'])
        return countryList

def getProductionCompanies(production_companies):
    if (production_companies == "[]"):
        return []
    else:
        companyItems = ast.literal_eval(production_companies)
        companyList = []
        for item in companyItems:
            companyList.append(item['name'])
        return companyList
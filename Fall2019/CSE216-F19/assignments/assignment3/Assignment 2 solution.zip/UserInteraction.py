from moviedatareader import csv_dict_reader
from datetime import datetime
from constants import getQuestionDictList, getGenresSet, getLanguageSet, getCountrySet

def userDateInput(first_date, last_date):
    print("Available date interval is from: ", first_date, "till", last_date)
    ufDate = input("Enter valid interval start date in the format YYYY-MM-DD: ")
    fDate = datetime.strptime(ufDate, "%Y-%m-%d").date()
    ulDate = input("Enter valid interval end date in the format YYYY-MM-DD: ")
    lDate = datetime.strptime(ulDate, "%Y-%m-%d").date()
    print("You entered: ", fDate, " - ", lDate)
    return fDate, lDate

def selectMovieSubsetDatewise(movieItems, fDate, lDate):
    moviesSubset = []
    for item in movieItems:
        if (item['date'] >= fDate and item['date'] <= lDate):
            moviesSubset.append(item)
    return moviesSubset

def selectMovieSubsetGenrewise(moviesSubset, genre):
    moviesGenreSubset = []
    for item in moviesSubset:
        if genre in item['record'].genreList:
            moviesGenreSubset.append(item)
    moviesGenreSubset.sort(key=lambda item:item['popularity'], reverse=True)
    return moviesGenreSubset

def selectMovieSubsetLanguageWise(moviesSubset, lang):
    moviesLangSubset = []
    for item in moviesSubset:
        if lang in item['record'].original_language:
            moviesLangSubset.append(item)
    moviesLangSubset.sort(key=lambda item:item['popularity'], reverse=True)
    return moviesLangSubset

def selectMovieSubsetCountryWise(moviesSubset, country):
    moviesCountrySubset = []
    for item in moviesSubset:
        if country in item['record'].production_countries:
            moviesCountrySubset.append(item)
    moviesCountrySubset.sort(key=lambda item:item['popularity'], reverse=True)
    return moviesCountrySubset

def userQuestionInput(qDictList):
    print("Available questions are: ")
    for item in qDictList:
        print(item['num'], ": ", item['question'])
    qnum = input("Select the number of any of the above question. ")
    return qnum

def userGenreInput(genresSet):
    print("Available genres are: ")
    for genre in genresSet:
        print(genre)
    uGenre = input("Type any genre from above list: ")
    return uGenre

def userCountryInput(countrySet):
    print("Available countries are: ")
    for country in countrySet:
        print(country)
    uCountry = input("Type any country code from above list: ")
    return uCountry

def userLangInput(LangSet):
    print("Available languages are: ")
    for lang in LangSet:
        print(lang)
    uLang = input("Type any language code from above list: ")
    return uLang

if __name__ == "__main__":
    f_obj = open("movies_metadata_edited.csv", encoding="utf8")
    movieItems = csv_dict_reader(f_obj)
    qDictList = getQuestionDictList()
    genreSet = getGenresSet()
    languageSet = getLanguageSet()
    countrySet = getCountrySet()
    print("First date: ", movieItems[0]['date'])
    print("Last date: ", movieItems[-1]['date'])
    contFlag = True
    while contFlag:
        fDate, lDate = userDateInput(movieItems[0]['date'], movieItems[-1]['date'])
        moviesSubset = selectMovieSubsetDatewise(movieItems, fDate, lDate)
        qNum = userQuestionInput(qDictList)

        if int(qNum) == 1:
            moviesSubset.sort(key=lambda item: item['popularity'], reverse=True)
            print("_" * 40)
            print("No.\tPopularity\tMovie title")
            print("_" * 40)
            for i in range(20):
                print(str(i+1) + ")\t", end="")
                print(moviesSubset[i]['popularity'], "\t", moviesSubset[i]['record'].title)
            print("_" * 40)
            print("Total number of movies produced during the period ", fDate, " - ", lDate,
                "is ", len(moviesSubset))
            print("_" * 40)
        elif int(qNum) == 2:
            uLang = userLangInput(languageSet)
            moviesLangSubset = selectMovieSubsetLanguageWise(moviesSubset, uLang)
            print("_" * 40)
            print("No.\tPopularity\tMovie title\tMovie language")
            print("_" * 40)
            for i in range(20):
                print(str(i + 1) + ")\t", end="")
                print(moviesLangSubset[i]['popularity'], "\t", moviesLangSubset[i]['record'].title, "\t", str(moviesLangSubset[i]['record'].original_language))
            print("_" * 40)
            print("Total number of movies with language ", uLang, " during the period ", fDate, " - ", lDate,
                "is ", len(moviesLangSubset))
            print("_" * 40)
        elif int(qNum) == 3:
            uGenre = userGenreInput(genreSet)
            moviesGenreSubset = selectMovieSubsetGenrewise(moviesSubset, uGenre)
            print("_" * 40)
            print("No.\tPopularity\tMovie title\tGenres")
            print("_" * 40)
            for i in range(20):
                print(str(i + 1) + ")\t", end="")
                print(moviesGenreSubset[i]['popularity'], "\t", moviesGenreSubset[i]['record'].title, "\t", str(moviesGenreSubset[i]['record'].genreList))
            print("_" * 40)
            print("Total number of movies with Genre ", uGenre, " during the period ", fDate, " - ", lDate,
                "is ", len(moviesGenreSubset))
            print("_" * 40)
        elif int(qNum) == 4:
            uCountry = userCountryInput(countrySet)
            moviesCountrySubset = selectMovieSubsetCountryWise(moviesSubset, uCountry)
            print("_" * 40)
            print("No.\tPopularity\tMovie title\tProduction countries")
            print("_" * 40)
            for i in range(20):
                print(str(i + 1) + ")\t", end="")
                print( moviesCountrySubset[i]['popularity'], "\t", moviesCountrySubset[i]['record'].title, "\t", str(moviesCountrySubset[i]['record'].production_countries))
            print("_" * 40)
            print("Total number of movies produced in country ", uCountry, " during the period ", fDate, " - ", lDate,
                "is ", len(moviesCountrySubset))
            print("_" * 40)
        elif int(qNum) == 5:
            moviesSubset.sort(key=lambda item: item['revenue'], reverse=True)
            print("_" * 40)
            print("No.\tRevenue\tMovie title")
            print("_" * 40)
            for i in range(20):
                print((i+1), ")\t", moviesSubset[i]['revenue'], "\t", moviesSubset[i]['record'].title)
            print("_" * 40)
            print("Total number of movies produced during the period ", fDate, " - ", lDate,
                "is ", len(moviesSubset))
            print("_" * 40)
        elif int(qNum) == 6:
            moviesSubset.sort(key=lambda item: item['runtime'], reverse=True)
            print("_" * 40)
            print("No.\tRuntime\tMovie title")
            print("_" * 40)
            for i in range(20):
                print(str(i + 1) + ")\t", end="")
                print(moviesSubset[i]['runtime'], "\t", moviesSubset[i]['record'].title)
            print("_" * 40)
            print("Total number of movies produced during the period ", fDate, " - ", lDate,
                "is ", len(moviesSubset))
            print("_" * 40)
        elif int(qNum) == 7:
            moviesSubset.sort(key=lambda item: item['popularity'], reverse=True)
            print("_" * 40)
            print("No.\tPopularity\tMovie title\tProduction companies")
            print("_" * 40)
            for i in range(20):
                print(str(i + 1) + ")\t", end="")
                print(moviesSubset[i]['popularity'], "\t", moviesSubset[i]['record'].title,
                      "\t", str(moviesSubset[i]['record'].production_companies))
            print("_" * 40)
            print("Total number of movies produced during the period ", fDate, " - ", lDate,
                "is ", len(moviesSubset))
            print("_" * 40)
        else:
            print("Enter correct choice.")
        uChoice = input("Enter [Y/N] to continue: ")
        if 'N' in uChoice or 'n' in uChoice:
            print("Thank you. Exiting!!")
            contFlag = False
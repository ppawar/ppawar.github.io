import csv
#----------------------------------------------------------------------
def csv_dict_reader(file_obj):
    """
    Read a CSV file using csv.DictReader
    The line is basically a dictionary object.
    """
    reader = csv.DictReader(file_obj, delimiter=',')
    for line in reader:
        print (line)
        print(line["id"]), print(line["title"],
        print(line["genres"]))
#----------------------------------------------------------------------
if __name__ == "__main__":
    with open("movies_metadata_edited.csv", encoding="utf8") as f_obj:
        csv_dict_reader(f_obj)
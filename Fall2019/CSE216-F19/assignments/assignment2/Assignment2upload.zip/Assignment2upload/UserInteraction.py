from moviedatareader import csv_dict_reader
from datetime import datetime
from constants import getQuestionDictList

def userDateInput(first_date, last_date):
    print("Available date interval is from: ", first_date, "till", last_date)
    ufDate = input("Enter valid interval start date in the format YYYY-MM-DD: ")
    fDate = datetime.strptime(ufDate, "%Y-%m-%d").date()
    ulDate = input("Enter valid interval end date in the format YYYY-MM-DD: ")
    lDate = datetime.strptime(ulDate, "%Y-%m-%d").date()
    print("You entered: ", fDate, " - ", lDate)
    return fDate, lDate

def userQuestionInput(qDictList):
    print("Available questions are: ")
    for item in qDictList:
        print(item['num'], ": ", item['question'])
    qnum = input("Select the number of any of the above question. ")
    return qnum

if __name__ == "__main__":
    f_obj = open("movies_metadata_edited.csv", encoding="utf8")
    movieItems = csv_dict_reader(f_obj)
    qDictList = getQuestionDictList()
    print("First date: ", movieItems[0]['date'])
    print("Last date: ", movieItems[-1]['date'])
    contFlag = True
    while contFlag:
        fDate, lDate = userDateInput(movieItems[0]['date'], movieItems[-1]['date'])
        qNum = userQuestionInput(qDictList)

        uChoice = input("Enter [Y/N] to continue: ")
        if 'N' in uChoice or 'n' in uChoice:
            print("Thank you. Exiting!!")
            contFlag = False
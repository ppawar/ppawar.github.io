class Tile:

    # This is a class variable for storing what will be displayed when the tile is unexplored, mine, or flagged.
    # If a tile is searched, it should display the number of mines nearby
    display_values = {"unexplored": " ",
                      "flagged": "F",
                      "mine": "M"}

    # This is the initializer for the Tile class, where you will need to add
    #  additional instance variables to keep track of information about a tile.
    def __init__(self):
        return

    # This returns a string that determines what a tile should look like. You will need
    #  to update this method when you change how a tile should be displayed.
    def __repr__(self):
        return self.display_values["unexplored"]

from tile import *

class Board:

    # This code initializes the board and sets up the tiles.
    #  You will add code to randomly place the passed in number_of_mines
    #  on the board. You will also need to then go through each Tile
    #  and determine the nearby mine counts for all of the tiles.
    def __init__(self, width, height, number_of_mines):
        if width <= 0 or height <= 0:
            raise Exception('Board width and height must be > 0')

        # The width and height could be calculated from our tiles, but saving
        #  them into variables to keep things simpler.
        self.height = height
        self.width = width

        self.tiles = []

        # Place all the tiles, but without any mines
        for row_index in range(height):
            new_row = []
            # Populate the row
            for column_index in range(width):
                new_row.append(Tile())
            # Add the populated row to the tiles list
            self.tiles.append(new_row)

    # This should return a tile at the specified row and column,
    #  or None if the position is not valid.
    def get_tile_for_position(self, row_index, column_index):
        return None

    # This should set the Tile at the specified row and column
    #  to be "flagged"
    def flag_position(self, row_index, column_index):
        return None

    # This should set the Tile at the specified row and column
    #  to be "searched". This method should return a value if
    #  the searched tile contains a mine, and a different
    #  value if the Tile searched did not contain a mine.
    def search_position(self, row_index, column_index):
        return None

    # Prints the entire board
    def print_board(self):
        height = self.height
        width = self.width

        # Print the column labels
        print("   ", end="")
        for column_index in range(self.width):
            # This translates the index into a letter.
            #  Note that 65 is where A starts on the ASCII table,
            #  66 is a B, and so on...
            print(chr(column_index+65)+" ", end="")
        print()

        for row_index in range(height):
            print(str(row_index) + ": ", end="") # Print the row labels
            for column_index in range(width):
                print(self.tiles[row_index][column_index], end="")
                print(" ", end="")
            print()
        print()





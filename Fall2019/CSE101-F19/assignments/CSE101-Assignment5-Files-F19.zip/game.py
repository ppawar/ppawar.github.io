"""
Run this file to get started.
"""
from board import *

class Game:

    def __init__(self, difficulty):
        if difficulty == "Beginner":
            self.board = Board(9, 9, 10)
        elif difficulty == "Intermediate":
            self.board = Board(16, 16, 40)
        elif difficulty == "Hard":
            self.board = Board(16, 30, 99)

    def play_game(self):
        # These instructions will be how your game will work once you finish the assignment.
        print("Welcome to Minesweeper!\n\nTo play, select a column and row to search, separated by spaces. For example:\n\te 3\nThis will search the tile in the 'e' column, row '3'.")
        print("\nYou can also flag (or unflag) a spot you suspect a mine by writing flag before the location to flag. For example:\n\tflag a 3\nThis will flag a suspected mine in the 'a' column, row '3'.")
        print()

        result = 0
        while result <= 0:
            self.board.print_board()
            command = input("Enter a position to search a tile or flag a mine: ")

            # Start here for Part 1A to write code here to check user input for flagging a row and column


if __name__ == "__main__":
    game = Game("Beginner")
    game.play_game()
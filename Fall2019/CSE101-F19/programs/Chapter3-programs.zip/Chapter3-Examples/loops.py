cities = ["Incheon", "Seoul", "Busan", "Jeju", "Onyang"]

for city in cities:
    print("I visited " + city + " in South Korea.")
    print(city + " has tall buildings.")

print(city)

cars = ['Kia', 'Honda', 'Toyota', 'Ford']
for car in cars:
    print(car + ' ' + str(len(car)))




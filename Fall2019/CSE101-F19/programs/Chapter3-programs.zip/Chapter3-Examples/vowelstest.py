vowels = ['a', 'e', 'i', 'o', 'u']
letter = 'e'
if letter in vowels:
    print('That letter is at index ' +
    str(vowels.index(letter)) + '.')
else:
    print('That letter is not in the list.')

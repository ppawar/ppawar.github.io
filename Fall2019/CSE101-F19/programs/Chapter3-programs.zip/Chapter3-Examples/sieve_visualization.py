import PythonLabs.SieveLab
worksheet = [None, None] + list(range(2, 400))
PythonLabs.SieveLab.view_sieve(worksheet)
PythonLabs.SieveLab.mark_multiples(2, worksheet)
PythonLabs.SieveLab.mark_multiples(3, worksheet)

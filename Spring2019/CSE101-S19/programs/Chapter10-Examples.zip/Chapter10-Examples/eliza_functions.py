# This file demonstrates some of the important functions used in the main
# algorithm in the Eliza program for simulating human intelligence.

from PythonLabs.ElizaLab import Eliza, Pattern

# Experiments with the find() method.
s1 = 'I was afraid of the cow.'
index = s1.find('cow')
print('Index of "cow" in \"' + s1 + '\": ' + str(index))

s1 = 'I am afraid of the dark.'
index = s1.find('cow')
print('Index of "cow" in \"' + s1 + '\": ' + str(index))

s1 = 'I saw birds on the house, birds at school, birds everywhere!'
index = s1.find('bird')
print('Index of "bird" in \"' + s1 + '\": ' + str(index))

s1 = 'I saw birds on the house, birds at school, birds everywhere!'
index = s1.find('bird', 7)
print('Index of "bird" in \"' + s1 + '\" after index 7: ' + str(index))

# Experiments with basic regular expression patterns.
p = Pattern('cow')
p.add_response('Tell me more about your farm')
p.add_response('Go on')
result = p.apply('I milked the cow and fed the chickens.')
print('Response to "I milked the cow and fed the chickens.":')
print('\t' + str(result))

result = p.apply('I scowled at the horse yesterday.')
print('Response to "I scowled at the horse yesterday.":')
print('\t' + str(result))

# Experiments with regular expressions that allow for multiple inputs.
p = Pattern('cow|pig|horse', ['Really?', 'Go on'])
result = p.apply('The horse jumped the fence.')
print('Response to "The horse jumped the fence.":')
print('\t' + str(result))

# Experiments with regular expressions that enable substitutions.
p = Pattern('cow|pig|horse')
p.add_response('You had a $1?')
p.add_response('How many $1s were on the farm?')
result = p.apply('The horse jumped the fence.')
print('Response to "The horse jumped the fence.":')
print('\t' + str(result))

# Experiments with more sophisticated regular expressions that enable substitutions.
p = Pattern('I (like|love|adore) my (cat|dog|ducks)')
p.add_response('Why do you $1 your $2?')
p.add_response('What about your $2 do you $1?')
result = p.apply('I adore my cat.')
print('Response to "I adore my cat.":')
print('\t' + str(result))

# Experiments with more sophisticated regular expressions that use wildcards.
p = Pattern('I am afraid of .*')
p.add_response('Why are you afraid of $1?')
result = p.apply('I am afraid of little green men')
print('Response to "I am afraid of little green men":')
print('\t' + str(result))

p = Pattern('I am (.*)', ['Are you really $1?'])
pronouns = {'I': 'you', 'your': 'my'}
result = p.apply('I am sorry I dropped your computer', post=pronouns)
print('Response to "I am sorry I dropped your computer":')
print('\t' + str(result))

p = Pattern('I am (.*)', ['Are you really $1?'])
pronouns = {'I': 'you', 'your': 'my'}
contractions = {"I'm": "I am"}
result = p.apply("I'm happy I lost", pre=contractions, post=pronouns)
print('Response to \"I\'m happy I lost:\"')
print('\t' + str(result))


def dec2bin(decimal):
    binary = ''
    while decimal > 0:
        remainder = decimal % 2
        binary = str(remainder) + binary
        decimal //= 2
    return binary


def parity(bits):
    p = 0
    for bit in bits:
        # uncomment the next line to see how p changes over time
        # print('p: {}, bit: {}, p ^ bit: {}'.format(p, bit, p ^ int(bit)))
        p = p ^ int(bit)  # can also be written p ^= bit
    return p



print('\nTesting parity():')
code = dec2bin(ord('A'))
print('A: ' + code)
print('Parity bit for A: ' + str(parity(code)))
code = dec2bin(ord('C'))
print('\nC: ' + code)
print('Parity bit for C: ' + str(parity(code)))

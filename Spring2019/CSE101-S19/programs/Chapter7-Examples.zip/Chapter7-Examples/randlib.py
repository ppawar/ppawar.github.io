#import time

x = 0       # global variable
a = 81      #global variable
c = 337     #global variable
m = 1000    #global variable
#x=int(time.time())%m

def rand():
    global x
    x = (a * x + c) % m
    return x

def reset(mult, inc, mod):
    global x, a, c, m
    x = 0
    a = mult
    c = inc
    m = mod

if __name__ == "__main__":
    print(rand())
    print(rand())
    print(rand())
    print(rand())
    # calling reset
    print("Resetting randlib...")
    reset(1, 7, 12)
    print(rand())
    print(rand())
    print(rand())
    # Simulating dice
    print("Rolling a dice...")
    print(rand() % 6 + 1)
    print(rand() % 6 + 1)
    print(rand() % 6 + 1)
    print(rand() % 6 + 1)
    print(rand() % 6 + 1)
    print(rand() % 6 + 1)
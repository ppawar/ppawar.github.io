def bmi(height, weight, units = 'metric'):
    if units == 'metric':
        return weight / height**2
    elif units == 'standard':
        return (weight * 703) / (height ** 2)
    else:
        return None

print(bmi(100, 150, 'standard'))  # 10.545
print(bmi(100, 150))              # 0.015
print(bmi(100, 150, 'metric'))    # 0.015
print(bmi(100, 150, 'unknown'))   # None

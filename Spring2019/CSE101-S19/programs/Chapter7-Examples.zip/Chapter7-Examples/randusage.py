from randlib import rand, reset

print(rand())
print(rand())
print(rand())
print(rand())
#calling reset
print("Resetting randlib...")
reset(1,7,12)
print(rand())
print(rand())
print(rand())
#Simulating dice
print("Rolling a dice...")
print(rand()%6+1)
print(rand()%6+1)
print(rand()%6+1)
print(rand()%6+1)
print(rand()%6+1)
print(rand()%6+1)
from PythonLabs.RecursionLab import RandomList, view_list, msort

nums = RandomList(8)
view_list(nums)
msort(nums)
input()
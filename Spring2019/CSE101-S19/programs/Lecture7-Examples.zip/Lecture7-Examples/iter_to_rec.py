def iter_sum(n):
    index = 1
    total = 0
    while index <= n:
        total += index
        index += 1
    return total


def rec_sum(n):
    return rec_sum_helper(n, 1)  # index == 1


def rec_sum_helper(n, index):
    if index == n:
        return n
    return index + rec_sum_helper(n, index + 1)

print(iter_sum(5))
print(rec_sum(5))


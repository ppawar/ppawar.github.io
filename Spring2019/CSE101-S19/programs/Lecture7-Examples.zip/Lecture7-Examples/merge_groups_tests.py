from PythonLabs.RecursionLab import RandomList, print_msort_brackets
import heapq

def merge_groups(a, group_size):
   for i in range(0, len(a), 2* group_size):
      j = i + group_size
      k = j + group_size
      a[i:k] = list(heapq.merge(a[i:j], a[j:k]))

nums = RandomList(16)
print('nums: ' + str(nums))

print('\nCalling merge_groups(nums, 1)')
print('nums before: ', end='')
print_msort_brackets(nums, 1)
merge_groups(nums, 1)
print('nums after:  ', end='')
print_msort_brackets(nums, 2)

print('\nCalling merge_groups(nums, 2)')
print('nums before: ', end='')
print_msort_brackets(nums, 2)
merge_groups(nums, 2)
print('nums after:  ', end='')
print_msort_brackets(nums, 4)

print('\nCalling merge_groups(nums, 4)')
print('nums before: ', end='')
print_msort_brackets(nums, 4)
merge_groups(nums, 4)
print('nums after:  ', end='')
print_msort_brackets(nums, 8)

print('\nCalling merge_groups(nums, 8)')
print('nums before: ', end='')
print_msort_brackets(nums, 8)
merge_groups(nums, 8)
print('nums after:  ', end='')
print_msort_brackets(nums, 16)

print('\nnums at end: ' + str(nums))


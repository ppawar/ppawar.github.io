class Student:
    """ Instance variables:
    name
    id
    major
    gpa
    """

    # Start adding things here.

import student


def main():
    # Start adding things here.


main()


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sample;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Sample JUnit-4-style test suite.
 * 
 * @author nb
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({sample.VectorsJUnit4Test.class,sample.UtilsJUnit4Test.class})
public class JUnit4TestSuite {

}
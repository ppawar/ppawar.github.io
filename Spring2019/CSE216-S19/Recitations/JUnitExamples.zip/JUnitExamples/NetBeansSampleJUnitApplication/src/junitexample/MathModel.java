/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package junitexample;

/**
 *
 * @author avh4
 */
public class MathModel {
    
    public int add(int a, int b) {
        return a + b;
    }
    
    public int subtract(int a, int b) {
        return a - b;
    }

}

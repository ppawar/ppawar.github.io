/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.sunyk.CSE216.preprocessing;

import com.opencsv.CSVReaderHeaderAware;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SUNY Korea CS
 */
public class CSVREaderDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            CSVREaderDemo csvReaderDemo = new CSVREaderDemo();
            csvReaderDemo.readCSVFile(args[0]);
            csvReaderDemo.readCSVFile(args[1]);
    }
    
    public void readCSVFile(String fileName) {
        System.out.println("Reading file " + fileName);
        try {
            FileReader fReader = new FileReader(fileName);
            CSVReaderHeaderAware csvReader = new CSVReaderHeaderAware(fReader);
            int numLines = 0;
            Map<String, String> values = csvReader.readMap();
            ++numLines;
            while (values != null) {
                for (String key: values.keySet()) {
                //System.out.println("Key is: " + key + " Value is:" + values.get(key));
                System.out.println("Reading line " + numLines);
                values = csvReader.readMap();
                ++numLines;
            }
            }
        } catch (IOException ex) {
            Logger.getLogger(CSVREaderDemo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
